module.exports = {
    "extends": "airbnb-base",
    "rules": {
        "linebreak-style": 0,
        "import/no-unresolved": 0,
        "no-underscore-dangle": 0,
        "arrow-parens": 0,
        "global-require": 0,
        "one-var": 0,
        "import/no-extraneous-dependencies": 0,
        "import/no-absolute-path": 0,
        "prefer-template": 0,
        "no-path-concat": 0,
        "no-console": 0
    }
};